// frontend/src/config.js

export const API_URL = "http://localhost:8000";
export const WS_URL = "ws://localhost:8000/ws/stt";   // <-- Correct WebSocket base
