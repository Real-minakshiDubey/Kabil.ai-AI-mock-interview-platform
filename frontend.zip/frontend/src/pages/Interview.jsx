import React, { useState, useRef, useEffect } from "react";
import "../styles/Interview.css";

import { WS_URL } from "../config";
import { startSession, saveQA, finalizeSession } from "../api";

export default function Interview() {
  
  const [sessionId, setSessionId] = useState(null);
  const [recording, setRecording] = useState(false);
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const [currentQuestion, setCurrentQuestion] = useState("Tell me about yourself");

  const [messages, setMessages] = useState([
    { id: 1, sender: "ai", text: "Tell me about yourself." },
  ]);

  
  const mediaRecorderRef = useRef(null);
  const wsRef = useRef(null);
  const chatEndRef = useRef(null);

  
  const videoRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const [isCameraOn, setIsCameraOn] = useState(false);

  let seq = 0; 


  const addMessage = (sender, text) => {
    setMessages((prev) => [...prev, { id: Date.now(), sender, text }]);
  };

  const autoScroll = () => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  useEffect(() => autoScroll(), [messages]);

  const startBackendSession = async () => {
    const data = await startSession("ml_engineer", "easy");
    setSessionId(data.session_id);
    console.log("SESSION:", data.session_id);

  
    wsRef.current = new WebSocket(`${WS_URL}/${data.session_id}`);

    wsRef.current.onopen = () => {
      console.log("🟢 WS connected");
    };

    wsRef.current.onmessage = (event) => {
      const msg = JSON.parse(event.data);

      if (msg.type === "transcript_partial") {
        
        setIsProcessing(false);
      }

      if (msg.type === "transcript_final") {
        console.log("FINAL:", msg.text);
      }
    };

    wsRef.current.onerror = (err) => console.error("WS Error:", err);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false,
      });

      mediaStreamRef.current = stream;
      videoRef.current.srcObject = stream;
      setIsCameraOn(true);
    } catch {
      alert("Camera permission denied!");
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraOn(false);
  };

  
  const startRecording = async () => {
    const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

    const mediaRecorder = new MediaRecorder(audioStream, {
      mimeType: "audio/webm",
    });

    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = async (event) => {
      const blob = event.data;
      const arrayBuffer = await blob.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      const base64 = btoa(String.fromCharCode(...bytes));

      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: "audio_chunk",
            chunk_b64: base64,
            seq: seq++,
          })
        );
      }
    };

    mediaRecorder.start(400); // send chunk every 400ms
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    wsRef.current?.send(JSON.stringify({ type: "end_interview" }));
    setRecording(false);
    setIsProcessing(true);
  };

  
  const startInterview = async () => {
    setInterviewStarted(true);

    await startBackendSession();
    startCamera();
    startRecording();
  };

  
  const endInterview = async () => {
    stopRecording();
    stopCamera();

    
    await saveQA(sessionId, {
      question_text: currentQuestion,
      answer_transcript: "User's final transcript or collected text",
      partial_score: { communication: 70, technical: 80, confidence: 85 },
    });

    
    const final = await finalizeSession(sessionId, {
      avg_scores: { communication: 70, technical: 80, confidence: 85 },
      improvement_plan: { tips: "Improve structured answers." },
      recommended_resources: [{ title: "DSA Basics", url: "https://google.com" }],
    });

    alert("Interview Finished! Overall Score: " + final.overall_score);
  };

  
  return (
    <div className="interview-container">
      <div className="logo-area">
        <span className="brand-text">Kabil.ai</span>
      </div>

      {!interviewStarted && (
        <div className="pre-interview">
          <h1>Ready for your AI Mock Interview?</h1>
          <button onClick={startInterview}>Start Interview</button>
        </div>
      )}

      {interviewStarted && (
        <div className="interview-live">
          <div className="camera-section">
            <video ref={videoRef} autoPlay playsInline className="live-camera" />
          </div>

          <div className="chat-panel">
            <div className="question-bar">
              <strong>Current Question: </strong> {currentQuestion}
            </div>

            <div className="chat-messages">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`bubble ${m.sender === "ai" ? "ai-bubble" : "user-bubble"}`}
                >
                  {m.text}
                </div>
              ))}

              {(recording || isProcessing) && (
                <div className="bubble ai-bubble loading-bubble">
                  <span className="typing-dot" />
                  <span className="typing-dot" />
                  <span className="typing-dot" />
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            <button className="end-btn" onClick={endInterview}>
              End Interview
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

