import React from "react";
import "../styles/result.css";

export default function Result() {
  return (
    <div className="result-container">
      {/* Logo */}
      <div className="logo-area">
        <img src="/logo.png" className="logo" alt="" />
        <span className="brand">Kabil.ai</span>
      </div>

      {/* Score */}
      <div className="main-score">7.5</div>
      <div className="score-label">Score</div>

      {/* Score Cards */}
      <div className="score-cards">
        <div className="score-card">
          <div className="title">Communication</div>
          <div className="value">8</div>
        </div>

        <div className="score-card">
          <div className="title">Technical</div>
          <div className="value">7</div>
        </div>

        <div className="score-card">
          <div className="title">Confidence</div>
          <div className="value">6</div>
        </div>
      </div>

      {/* Strengths */}
      <div className="section-title">Strengths</div>
      <div className="bullet good">
        ✔ Clearly explained technical concepts
      </div>

      {/* Weaknesses */}
      <div className="section-title">Weaknesses</div>
      <div className="bullet bad">
        ✖ Occasional lack of eye contact
      </div>

      {/* Improvement */}
      <div className="section-title">Improvement</div>
      <div className="long-text">
        • Work on maintaining better eye contact throughout the interview
      </div>

      {/* Button */}
      <button className="retake-btn">Retake Interview</button>
    </div>
  );
}
