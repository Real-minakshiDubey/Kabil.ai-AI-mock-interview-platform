import React from "react";
import "../styles/Home.css";

export default function Home() {
  return (
    <div className="home-container">
      
      {/* Logo */}
      <div className="logo-area">
        <img src="/logo.png" className="logo" alt="logo" />
        <span className="brand">Kabil.ai</span>
      </div>

      {/* Headings */}
      <h1 className="main-title">Ace your interview<br />with AI</h1>

      <p className="sub-title">
        Practice your interview skills with<br />
        real-time feedback.
      </p>

      {/* Button */}
      <button className="primary-btn">Start Practicing</button>

      {/* Role Selection */}
      <h2 className="role-title">Select your role</h2>

      <div className="role-boxes">

        <div className="role-card">Software Engineer</div>
        <div className="role-card">Data Scientist</div>
        <div className="role-card">Product Manager</div>

      </div>
    </div>
  );
}
