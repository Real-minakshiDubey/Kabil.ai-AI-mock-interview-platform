import React from 'react'
import { Link, useLocation } from 'react-router-dom'

export default function Navbar() {
  const loc = useLocation()
  const active = (p) => (loc.pathname === p ? { fontWeight: 700 } : {})

  return (
    <header style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 20px',
      borderBottom: '1px solid #222'
    }}>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <img src="/logo.png" alt="KABIL.AI" style={{ width: 38, height: 38 }} />
        <div style={{ fontWeight: 700, fontSize: 20 }}>KABIL.AI</div>
      </div>

      <nav style={{ display: 'flex', gap: 16 }}>
        <Link to="/" style={active('/')}>Home</Link>
        <Link to="/interview" style={active('/interview')}>Interview</Link>
        <Link to="/result" style={active('/result')}>Result</Link>
      </nav>

    </header>
  )
}
