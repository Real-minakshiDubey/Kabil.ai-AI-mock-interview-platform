export default function ScoreCard({ title, score }) {
  return (
    <div className="card" style={{
      border: "1px solid var(--primary)",
      textAlign: "center"
    }}>
      <h3 className="h3">{title}</h3>
      <p className="h1" style={{ marginTop: 10 }}>{score}</p>
    </div>
  );
}
