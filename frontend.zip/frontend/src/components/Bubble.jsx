export default function Bubble({ text, sender }) {
  return (
    <div className={sender === "ai" ? "ai-bubble" : "user-bubble"}>
      {text}
    </div>
  );
}
