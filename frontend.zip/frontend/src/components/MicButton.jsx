export default function MicButton() {
  return (
    <button className="mic">
      🎤
    </button>
  );
}
