// frontend/src/api.js
import axios from "axios";
import { API_URL } from "./config";

const api = axios.create({
  baseURL: API_URL,
});

// Start Interview Session
export const startSession = async (role, difficulty = "easy") => {
  const res = await api.post("/api/session/start", {
    role,
    difficulty,
  });
  return res.data;
};

// Save Q/A
export const saveQA = async (sessionId, payload) => {
  const res = await api.post(`/api/session/${sessionId}/qa`, payload);
  return res.data;
};

// Finalize Interview Session
export const finalizeSession = async (sessionId, payload) => {
  const res = await api.post(`/api/session/${sessionId}/finalize`, payload);
  return res.data;
};

export default api;
